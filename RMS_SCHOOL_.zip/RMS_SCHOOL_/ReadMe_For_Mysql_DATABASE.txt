Run : mysql-5.5.46-win32.msi (or Double Click)
#########################################
1. Welcome to the MySQL Server 5.5 Setup Wizard
	Click "Next"
2. End-User License Agreement
     I  accept the terms in the License Agreement
     check box : Accept by clicking into check box
     than Click "Next"
3.  Choose Setup Type
     Typical 'Click on Typical'
      or	
     Click "Next"
4. Ready to install MySQL Server 5.5
    Click "Install"
    (Please Wait for few Seconds or so .... it take time to Install)
    'User Access Control' Message Box appear
     'Do you want to allow the following program to
      install software in this computer ?'
     Click "YES" as  Windows Administrator Permission
5. Installing MySQL Server 5.5 
    'Please wait while the setup wizard install MySQL Server 5.5
     Click "Next"
6. The MySQL Enterprise Monitor Service
     Click "Next"
7. Completed the MySQL Server 5.5 Setup Wizard
     Click "Finish"
8. 'User Access Control' Message Box appear
     'Do you want to allow the following program to
      install software in this computer ?'
     Click "YES" as  Windows Administrator Permission
9. Welcome to the MySQL Server Instance Configuration 
     Wizard 1.0.17.0
     Click "Next"
10. MySQL Server Instance Configuration
     . Detailed Configuration (<<< click ok/on radio box)
     than Click "Next"
11. MySQL Server Instance Configuration
     .Developer Machine (<<< click ok/on radio box)
     than Click "Next"
12. MySQL Server Instance Configuration
     .Multifunctional Database (<<< click ok/on radio box)
     than Click "Next"
13.MySQL Server Instance Configuration
     InnoDB Tablespace Settings
     No Change (Don't Change path)
     than Click "Next"
14. MySQL Server Instance Configuration
      .Decision Support(DSS)/OLAP
       at bottom line 'Concurrent connections: 15' ( On Drop Box)
      No Change (Don't Change)
      Click "Next" 
15. MySQL Server Instance Configuration
     Port Number : 3306 
     'Yes' for Add Firewall Exception for this port
    *** Important Click "Yes" in Check Box to Add Firewall Exception
     Click "Next"
16. MySQL Server Instance Configuration
     .Standard Chareter Set (<<< click ok/on radio box)
     at bottom line >>>
     Character Set : latin1
     Click "Next"
17. MySQL Server Instance Configuration
     .Install As Windows Service (<<< click ok/on Check Box)
     Service Name MySQL (on drop down box)
     "YES" Launch the MySQL Server automatically
     Click "Next"
18. MySQL Server Instance Configuration
      .Modify Security Settings
      New root password :
      pass (Enter pass the root password , in small letters only) 
      Confirm :
      pass (Retype pass the root password , in small letters only)
      clcik "YES" to Enable root access from remote machines
      *** Important : pass is the password in small letters , in small letters only
      Click "Next"
19. MySQL Server Instance Configuration
     Please press [Execute] to start the configuration.
     Click "Execute"
20. Please Wait for few seconds It takes time ....
     'not responding message may reported on message box'
     But it is still working , do not interrupt .... wait for few seconds/minutes
     *** Do Not Interrupt this Process it takes time to few miniutes
     Click "Finish"