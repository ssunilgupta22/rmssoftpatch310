If Error reported after completion of MySQL Setup
Wizard.
 
than go to C:\ drive

write given address on addressbar
'C:\ProgramData' Enter 
(*** this is hidden folder)
MySQL Folder is present on Shown Directory
Delete MySQL Folder Completely
Restart Your Computer
#######################################
Start MySQL Server 5.5 Setup wizard Once Again Carefully
as Mention in ReadMe_for_MySQL_DATABASE.txt file
Done !