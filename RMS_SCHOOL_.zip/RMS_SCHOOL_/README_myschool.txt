Please Read to run hassle free execution of my_school.exe Applicaton:

1. At First Install MySQL Server Database 5.5 version, 
2. Installation Procedure is given in README.txt  after Download of 
    MySQL Server 5.5 Database from www.rmsoft.tk 
3. After Successful complition of MySQL server 
   Open : my_school folder > double click/run > my_school.exe 
4. Any Changes Regarding you school administration :
    Open :  my_school folder > resource folder > config.csv
    (it will be open in excell sheet if you have ms office installed in your machine)
    read carefully and edit accordingly , my_school.exe read this file values before run
    so, made any changes carefully in config.csv
    MONTHLY_TEST, HALF_YEARLY,ANNUAL: Maximum Marks 
    ANNUAL_MONTH : Month of conduction Annual Examination
    SESSION_START	: 4 means in April (edit Accordingly)
    SUBJECTS_H : _H for Higher Classes greater than 5th class	
    SUBJECTS_L : _L for Lower Classes less than 6th class
    SUBJECTS_ROW_H  : Number of subjects shows in marksheet for Heigher Class 
    SUBJECTS_ROW_L  : Number of subjects shows in marksheet for Lower Class 
    Reset your Marksheet Paper in my_school folder by editing sspdfbase.pdf
    and then Adjust paper margin by taking print out of marksheet and ajusting values in config.csv carefully.
    ** This is Demo Version 
    				(fare values)	(fare values)											
FARE_MODE1	RIKSHAW	50	100	150	200													
FARE_MODE2	AUTO	60	110	160	210													
FARE_MODE3	BUS	100	150	200	250													
LATE_FEE_DATE	15																	
HALF_YEARLY_MONTH	10																	
ANNUAL_MONTH	3																	
MONTHLY_TEST	30																	
HALF_YEARLY	100																	
ANNUAL		100																	
SESSION_START	4																	
FEE_HEADINGS	Admission Fee	Tution Fee	Maintenance Fee	Late Fee	Others	Basic Convenience	Examination Fee	Additional Fee1	Additional Fee2									
MONTHS_HEAD	JAN	FEB	MAR	APR	MAY	JUNE	JULY	AUG	SEP	OCT	NOV	DEC	H-Yrly	Annual				
SUBJECTS_H	Hindi	English	Science	Maths	G.K	Hindi Oral	English Oral	Chemistry	Physics	Biology	Civics	History	Geography	Commerce	Sc.ACT.	Sports	Others	Atnds.
SUBJECTS_L	Hindi	English	Science	Maths	G.K	Sports	Hindi Oral	English Oral	Chemistry	Physics	Biology	Civics	History	Geography	Commerce	Sc.ACT.	Sports	Others
SUBJECTS_ROW_H  	18																	
SUBJECTS_ROW_L  	6																	
H_CLASS_FONT_SIZE	7																	
L_CLASS_FONT_SIZE	9																	
HEADER_MARGIN	150																	
FOOTER_MARGIN	10																	
LEFT_MARGIN	4																	
RIGHT_MARGIN	0																	
EXTEND_MARGIN	1																	
SLOGAN	KEEP PRACTICING																	
																
